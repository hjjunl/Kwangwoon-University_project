#include <iostream>
#include "MyDoubleVector.h"
using namespace std;

int main()
{
	MyDoubleVector vector1;
	MyDoubleVector vector2;
	MyDoubleVector vector3;

	vector1.push_back(1);
	vector1.push_back(2);
	vector1.push_back(3);
	vector1.push_back(4);
	cout << " vector_1�� ����: ";
	for (int i = 0; i < vector1.size(); i++)
	{
		cout << vector1[i] << " ";
	}
	cout << endl;

	cout << " push_back�� vector_2�� ���ش�(1, 8, 9)" << endl;
	vector2.push_back(1);
	vector2.push_back(8);
	vector2.push_back(9);
	cout << " vector2�� ����: ";
	for (int i = 0; i < vector2.size(); i++)
	{
		cout << vector2[i] << " ";
	}
	cout << endl << endl;

	cout << " vector1�� �� : ";
	for (int i = 0; i < vector1.size(); i++)
	{
		cout << vector1[i] << " ";
	}
	cout << endl;
	vector1.pop_back();
	cout << "pop_back���� vector1�� ��" << endl;
	for (int i = 0; i < vector1.size(); i++)
	{
		cout << vector1[i] << " ";
	}
	cout << endl;

	cout << " vector1, vector2, vector3'�� �뷮��" << endl;
	cout << " vector1�� �뷮 : " << vector1.capacity() << endl;
	cout << " vector2�� �뷮 : " << vector2.capacity() << endl;
	cout << " vector4�� �뷮 : " << vector3.capacity() << endl;
	cout << endl;
	cout << " vector1 * vector2 : " << vector1 * vector2 << endl;
	cout << endl;

	cout << " vector3 = -vector_1" << endl;
	vector3 = -vector1;
	cout << " vector3�� �� : ";
	for (int i = 0; i < vector3.size(); i++)
	{
		cout << vector3[i] << " ";
	}
	cout << endl << endl;
	cout << " vector3 = vector1 + vector2" << endl;
	vector3 = vector1 + vector2;
	cout << " vector3 element�� �� ";
	for (int i = 0; i < vector3.size(); i++)
	{
		cout << vector3[i] << " ";
	}
	cout<< endl;

	cout << " vector3 = vector1 - vector2" << endl;
	vector3 = vector1 - vector2;
	cout << " vector3�� �� ";
	for (int i = 0; i < vector3.size(); i++)
	{
		cout << vector3[i] << " ";
	}
	cout << endl;

	cout << "clear() vector3" << endl;
	vector3.clear();

	cout << " empty() vector1, vector2, vector3" << endl;
	cout << " vector1 : " << vector1.empty() << endl;
	cout << " vector2 : " << vector2.empty() << endl;
	cout << " vector3 : " << vector3.empty() << endl;
	cout << endl;

	int v = 0;
	cout << " == vector1, vector2, vector3" << endl;
	cout << " vector3 = vector1" << endl;
	vector3 = vector1;
	cout << " vector1 == vector2 -> " << v << endl;
	v = vector1 == vector3;
	cout << " vector1 == vector3 -> " << v;
	cout << endl;

	cout << " += operator vector1, vector2" << endl;
	vector1 += vector2;
	cout << " vector1 += vector2 -> ";
	cout << "vector1�� �� ";
	for (int i = 0; i < vector1.size(); i++)
	{
		cout << vector1[i] << " ";
	}
	cout << endl;

	cout << "[] vector1" << endl;
	cout << "vector1[2] -> " << vector1[2];
	cout << endl;

	cout << " () vector1" << endl;
	cout << " vector1(9) -> ";
	vector1(9);
	cout << "vector1 �� ";
	for (int i = 0; i < vector1.size(); i++)
	{
		cout << vector1[i] << " ";
	}
	cout <<endl;
}