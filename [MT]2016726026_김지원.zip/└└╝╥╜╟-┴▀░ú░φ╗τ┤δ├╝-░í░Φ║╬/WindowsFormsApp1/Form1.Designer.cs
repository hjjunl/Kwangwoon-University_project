﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTime = new System.Windows.Forms.Label();
            this.btnPrev = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.lvwOutgo = new System.Windows.Forms.ListView();
            this.lvwIncome = new System.Windows.Forms.ListView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbOutName = new System.Windows.Forms.TextBox();
            this.tbOutMoney = new System.Windows.Forms.TextBox();
            this.btnAddO = new System.Windows.Forms.Button();
            this.btnDelO = new System.Windows.Forms.Button();
            this.lblOutgo = new System.Windows.Forms.Label();
            this.lblIncome = new System.Windows.Forms.Label();
            this.btnDelI = new System.Windows.Forms.Button();
            this.btnAddI = new System.Windows.Forms.Button();
            this.tbInMoney = new System.Windows.Forms.TextBox();
            this.tbInName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblSum = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblTime.Location = new System.Drawing.Point(345, 55);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(135, 29);
            this.lblTime.TabIndex = 0;
            this.lblTime.Text = "2020.05.";
            // 
            // btnPrev
            // 
            this.btnPrev.Location = new System.Drawing.Point(275, 55);
            this.btnPrev.Name = "btnPrev";
            this.btnPrev.Size = new System.Drawing.Size(30, 30);
            this.btnPrev.TabIndex = 1;
            this.btnPrev.Text = "◀";
            this.btnPrev.UseVisualStyleBackColor = true;
            this.btnPrev.Click += new System.EventHandler(this.btnPrev_Click);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(515, 55);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(30, 30);
            this.btnNext.TabIndex = 2;
            this.btnNext.Text = "▶";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // lvwOutgo
            // 
            this.lvwOutgo.HideSelection = false;
            this.lvwOutgo.Location = new System.Drawing.Point(50, 120);
            this.lvwOutgo.Name = "lvwOutgo";
            this.lvwOutgo.Size = new System.Drawing.Size(330, 220);
            this.lvwOutgo.TabIndex = 3;
            this.lvwOutgo.UseCompatibleStateImageBehavior = false;
            // 
            // lvwIncome
            // 
            this.lvwIncome.HideSelection = false;
            this.lvwIncome.Location = new System.Drawing.Point(452, 120);
            this.lvwIncome.Name = "lvwIncome";
            this.lvwIncome.Size = new System.Drawing.Size(330, 220);
            this.lvwIncome.TabIndex = 4;
            this.lvwIncome.UseCompatibleStateImageBehavior = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(110, 350);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 12);
            this.label1.TabIndex = 5;
            this.label1.Text = "지출 내역 : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(110, 380);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 12);
            this.label2.TabIndex = 6;
            this.label2.Text = "지출 금액 : ";
            // 
            // tbOutName
            // 
            this.tbOutName.Location = new System.Drawing.Point(185, 346);
            this.tbOutName.Name = "tbOutName";
            this.tbOutName.Size = new System.Drawing.Size(100, 21);
            this.tbOutName.TabIndex = 7;
            // 
            // tbOutMoney
            // 
            this.tbOutMoney.Location = new System.Drawing.Point(185, 376);
            this.tbOutMoney.Name = "tbOutMoney";
            this.tbOutMoney.Size = new System.Drawing.Size(100, 21);
            this.tbOutMoney.TabIndex = 8;
            // 
            // btnAddO
            // 
            this.btnAddO.Location = new System.Drawing.Point(291, 346);
            this.btnAddO.Name = "btnAddO";
            this.btnAddO.Size = new System.Drawing.Size(75, 23);
            this.btnAddO.TabIndex = 9;
            this.btnAddO.Text = "등록";
            this.btnAddO.UseVisualStyleBackColor = true;
            this.btnAddO.Click += new System.EventHandler(this.btnAddO_Click);
            // 
            // btnDelO
            // 
            this.btnDelO.Location = new System.Drawing.Point(291, 376);
            this.btnDelO.Name = "btnDelO";
            this.btnDelO.Size = new System.Drawing.Size(75, 23);
            this.btnDelO.TabIndex = 10;
            this.btnDelO.Text = "제거";
            this.btnDelO.UseVisualStyleBackColor = true;
            this.btnDelO.Click += new System.EventHandler(this.btnDelO_Click);
            // 
            // lblOutgo
            // 
            this.lblOutgo.AutoSize = true;
            this.lblOutgo.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblOutgo.Location = new System.Drawing.Point(48, 413);
            this.lblOutgo.Name = "lblOutgo";
            this.lblOutgo.Size = new System.Drawing.Size(119, 19);
            this.lblOutgo.TabIndex = 11;
            this.lblOutgo.Text = "총 지출 : 0원";
            // 
            // lblIncome
            // 
            this.lblIncome.AutoSize = true;
            this.lblIncome.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblIncome.Location = new System.Drawing.Point(448, 413);
            this.lblIncome.Name = "lblIncome";
            this.lblIncome.Size = new System.Drawing.Size(119, 19);
            this.lblIncome.TabIndex = 18;
            this.lblIncome.Text = "총 수입 : 0원";
            // 
            // btnDelI
            // 
            this.btnDelI.Location = new System.Drawing.Point(691, 376);
            this.btnDelI.Name = "btnDelI";
            this.btnDelI.Size = new System.Drawing.Size(75, 23);
            this.btnDelI.TabIndex = 17;
            this.btnDelI.Text = "제거";
            this.btnDelI.UseVisualStyleBackColor = true;
            this.btnDelI.Click += new System.EventHandler(this.btnDelI_Click);
            // 
            // btnAddI
            // 
            this.btnAddI.Location = new System.Drawing.Point(691, 346);
            this.btnAddI.Name = "btnAddI";
            this.btnAddI.Size = new System.Drawing.Size(75, 23);
            this.btnAddI.TabIndex = 16;
            this.btnAddI.Text = "등록";
            this.btnAddI.UseVisualStyleBackColor = true;
            this.btnAddI.Click += new System.EventHandler(this.btnAddI_Click);
            // 
            // tbInMoney
            // 
            this.tbInMoney.Location = new System.Drawing.Point(585, 376);
            this.tbInMoney.Name = "tbInMoney";
            this.tbInMoney.Size = new System.Drawing.Size(100, 21);
            this.tbInMoney.TabIndex = 15;
            // 
            // tbInName
            // 
            this.tbInName.Location = new System.Drawing.Point(585, 346);
            this.tbInName.Name = "tbInName";
            this.tbInName.Size = new System.Drawing.Size(100, 21);
            this.tbInName.TabIndex = 14;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(510, 380);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 12);
            this.label4.TabIndex = 13;
            this.label4.Text = "수입 금액 : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(510, 350);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 12);
            this.label5.TabIndex = 12;
            this.label5.Text = "수입 내역 : ";
            // 
            // lblSum
            // 
            this.lblSum.AutoSize = true;
            this.lblSum.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblSum.Location = new System.Drawing.Point(361, 448);
            this.lblSum.Name = "lblSum";
            this.lblSum.Size = new System.Drawing.Size(119, 19);
            this.lblSum.TabIndex = 19;
            this.lblSum.Text = "총 자산 : 0원";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(374, 484);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(95, 35);
            this.btnSave.TabIndex = 20;
            this.btnSave.Text = "이 달 가계부 저장";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(834, 531);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.lblSum);
            this.Controls.Add(this.lblIncome);
            this.Controls.Add(this.btnDelI);
            this.Controls.Add(this.btnAddI);
            this.Controls.Add(this.tbInMoney);
            this.Controls.Add(this.tbInName);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblOutgo);
            this.Controls.Add(this.btnDelO);
            this.Controls.Add(this.btnAddO);
            this.Controls.Add(this.tbOutMoney);
            this.Controls.Add(this.tbOutName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lvwIncome);
            this.Controls.Add(this.lvwOutgo);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnPrev);
            this.Controls.Add(this.lblTime);
            this.Name = "Form1";
            this.Text = "Household Ledger Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Button btnPrev;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.ListView lvwOutgo;
        private System.Windows.Forms.ListView lvwIncome;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbOutName;
        private System.Windows.Forms.TextBox tbOutMoney;
        private System.Windows.Forms.Button btnAddO;
        private System.Windows.Forms.Button btnDelO;
        private System.Windows.Forms.Label lblOutgo;
        private System.Windows.Forms.Label lblIncome;
        private System.Windows.Forms.Button btnDelI;
        private System.Windows.Forms.Button btnAddI;
        private System.Windows.Forms.TextBox tbInMoney;
        private System.Windows.Forms.TextBox tbInName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblSum;
        private System.Windows.Forms.Button btnSave;
    }
}

