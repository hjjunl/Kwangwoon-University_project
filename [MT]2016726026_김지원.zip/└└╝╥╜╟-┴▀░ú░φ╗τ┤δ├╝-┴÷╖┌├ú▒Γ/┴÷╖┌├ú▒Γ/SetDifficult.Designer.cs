﻿namespace 지뢰찾기
{
    partial class SetDifficult
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdobtnHard = new System.Windows.Forms.RadioButton();
            this.rdobtnNormal = new System.Windows.Forms.RadioButton();
            this.rdobtnEasy = new System.Windows.Forms.RadioButton();
            this.btnOk = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.groupBox1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnOk, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 49F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(184, 228);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdobtnHard);
            this.groupBox1.Controls.Add(this.rdobtnNormal);
            this.groupBox1.Controls.Add(this.rdobtnEasy);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(20, 20);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(20);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(144, 139);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "난이도 선택";
            // 
            // rdobtnHard
            // 
            this.rdobtnHard.AutoSize = true;
            this.rdobtnHard.Location = new System.Drawing.Point(27, 105);
            this.rdobtnHard.Name = "rdobtnHard";
            this.rdobtnHard.Size = new System.Drawing.Size(98, 16);
            this.rdobtnHard.TabIndex = 2;
            this.rdobtnHard.TabStop = true;
            this.rdobtnHard.Text = "고급 : 30 x 16";
            this.rdobtnHard.UseVisualStyleBackColor = true;
            this.rdobtnHard.CheckedChanged += new System.EventHandler(this.rdobtnHard_CheckedChanged);
            // 
            // rdobtnNormal
            // 
            this.rdobtnNormal.AutoSize = true;
            this.rdobtnNormal.Location = new System.Drawing.Point(27, 67);
            this.rdobtnNormal.Name = "rdobtnNormal";
            this.rdobtnNormal.Size = new System.Drawing.Size(98, 16);
            this.rdobtnNormal.TabIndex = 1;
            this.rdobtnNormal.TabStop = true;
            this.rdobtnNormal.Text = "중급 : 16 x 16";
            this.rdobtnNormal.UseVisualStyleBackColor = true;
            this.rdobtnNormal.CheckedChanged += new System.EventHandler(this.rdobtnNormal_CheckedChanged);
            // 
            // rdobtnEasy
            // 
            this.rdobtnEasy.AutoSize = true;
            this.rdobtnEasy.Location = new System.Drawing.Point(27, 29);
            this.rdobtnEasy.Name = "rdobtnEasy";
            this.rdobtnEasy.Size = new System.Drawing.Size(86, 16);
            this.rdobtnEasy.TabIndex = 0;
            this.rdobtnEasy.TabStop = true;
            this.rdobtnEasy.Text = "초급 : 9 x 9";
            this.rdobtnEasy.UseVisualStyleBackColor = true;
            this.rdobtnEasy.CheckedChanged += new System.EventHandler(this.rdobtnEasy_CheckedChanged);
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(60, 189);
            this.btnOk.Margin = new System.Windows.Forms.Padding(60, 10, 60, 3);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(64, 30);
            this.btnOk.TabIndex = 1;
            this.btnOk.Text = "확인";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // SetDifficult
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(184, 228);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "SetDifficult";
            this.Text = "SetDifficult";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdobtnHard;
        private System.Windows.Forms.RadioButton rdobtnNormal;
        private System.Windows.Forms.RadioButton rdobtnEasy;
        private System.Windows.Forms.Button btnOk;
    }
}