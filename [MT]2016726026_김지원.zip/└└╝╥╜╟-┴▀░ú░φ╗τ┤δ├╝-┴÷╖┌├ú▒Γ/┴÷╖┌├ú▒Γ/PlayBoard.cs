﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 지뢰찾기
{
    public partial class PlayBoard : Form
    {
        public GameInfo gameinfo = new GameInfo();
        public MyButton[,] btns = null;
        public PlayBoard()
        {
            InitializeComponent();
        }
        public PlayBoard(int num)
        {
            InitializeComponent();

            switch (num)
            {
                case 1:
                    btns = SetEasy();
                    break;
                case 2:
                    btns = SetNormal();
                    break;
                case 3:
                    btns = SetHard();
                    break;
            }
        }
        private MyButton[,] SetEasy()
        {
            this.Width = 300;
            this.Height = 330;
            MyButton[,] btns = new MyButton[9,9];
            gameinfo.SetEasy();
            int[] mine = MakeMine(1);

            for(int i = 0; i < 9; i++)
            {
                for(int j = 0; j < 9; j++)
                {
                    btns[i,j] = new MyButton();

                    btns[i, j].Name = "btn"+i+","+j;
                    btns[i, j].Size = new Size(30, 30);
                    btns[i, j].Location = new Point(30 * i, 30 * j);
                    btns[i, j].MouseDown += Clicked;
                    this.Controls.Add(btns[i, j]);
                }
            }
            for(int i = 0; i < mine.Length; i++)        //지뢰심기
            {
                btns[mine[i] / 9, mine[i] % 9].setMine(true);
            }
            
            SetNum(btns,1);

            return btns;
        }

        private MyButton[,] SetNormal()     //중급 난이도 셋팅
        {
            this.Width = 510;
            this.Height = 540;
            MyButton[,] btns = new MyButton[16, 16];
            gameinfo.SetNormal();
            int[] mine = MakeMine(2);

            for (int i = 0; i < 16; i++)
            {
                for (int j = 0; j < 16; j++)
                {
                    btns[i, j] = new MyButton();

                    btns[i, j].Name = "btn" + i + "," + j;
                    btns[i, j].Size = new Size(30, 30);
                    btns[i, j].Location = new Point(30 * i, 30 * j);
                    btns[i, j].MouseDown += Clicked;
                    this.Controls.Add(btns[i, j]);
                }
            }
            for (int i = 0; i < mine.Length; i++)        //지뢰심기
            {
                btns[mine[i] / 16, mine[i] % 16].setMine(true);
            }

            SetNum(btns, 2);
            return btns;
        }       
        private MyButton[,] SetHard()
        {
            this.Width = 930;
            this.Height = 540;
            MyButton[,] btns = new MyButton[30, 16];
            gameinfo.SetHard();
            int[] mine = MakeMine(3);

            for (int i = 0; i < 30; i++)
            {
                for (int j = 0; j < 16; j++)
                {
                    btns[i, j] = new MyButton();

                    btns[i, j].Name = "btn" + i + "," + j;
                    btns[i, j].Size = new Size(30, 30);
                    btns[i, j].Location = new Point(30 * i, 30 * j);
                    btns[i, j].MouseDown += Clicked;
                    this.Controls.Add(btns[i, j]);
                }
            }
            for (int i = 0; i < mine.Length; i++)        //지뢰심기
            {
                btns[mine[i] / 16, mine[i] % 16].setMine(true);
            }

            SetNum(btns, 3);
            return btns;
        }           //고급 난이도 셋팅
        private int[] MakeMine(int dif)
        {
            int[] mines = null;
            Random rdm = new Random();
            switch (dif)
            {
                case 1:
                    mines = new int[10];
                    for(int i = 0; i < mines.Length; i++)
                    {
                        mines[i] = rdm.Next(0, 81);
                        for(int j = 0; j < i; j++)
                        {
                            if(mines[i] == mines[j])
                            {
                                i--;
                                break;
                            }
                        }
                    }
                    break;
                case 2:
                    mines = new int[40];
                    for (int i = 0; i < mines.Length; i++)
                    {
                        mines[i] = rdm.Next(0, 256);
                        for (int j = 0; j < i; j++)
                        {
                            if (mines[i] == mines[j])
                            {
                                i--;
                                break;
                            }
                        }
                    }
                    break;
                case 3:
                    mines = new int[99];
                    for (int i = 0; i < mines.Length; i++)
                    {
                        mines[i] = rdm.Next(0, 480);
                        for (int j = 0; j < i; j++)
                        {
                            if (mines[i] == mines[j])
                            {
                                i--;
                                break;
                            }
                        }
                    }
                    break;
            }
            return mines;
        }       //랜덤으로 지뢰번호 생성
        private MyButton[,] SetNum(MyButton[,] btns,int dif)
        {
            int r = 0, c = 0;
            if (dif == 1) 
            {
                r = 9; c = 9; 
            }
            else if(dif == 2)
            {
                r = 16;c = 16;
            }
            else if (dif == 3)
            {
                r = 30;c = 16;
            }
            for (int i = 0; i < r; i++)
            {
                for(int j = 0; j < c; j++)
                {
                    if (btns[i, j].GetMine())
                        continue ;
                    int count = 0;
                    if(i==0 && j== 0)                   //맨 왼쪽 위 버튼
                    {
                        if (btns[i + 1, j].GetMine())
                            count++;
                        if (btns[i, j + 1].GetMine())
                            count++;
                        if (btns[i + 1, j + 1].GetMine())
                            count++;
                        btns[i, j].SetNum(count);
                    }
                    else if(i == r-1 && j == 0)           //맨 오른쪽 위 버튼
                    {
                        if (btns[i - 1, j].GetMine())
                            count++;
                        if (btns[i, j + 1].GetMine())
                            count++;
                        if (btns[i - 1, j + 1].GetMine())
                            count++;
                        btns[i, j].SetNum(count);
                    }
                    else if (i == 0 && j == c - 1)      //맨 왼쪽 아래 버튼
                    {
                        if (btns[i + 1, j].GetMine())
                            count++;
                        if (btns[i, j - 1].GetMine())
                            count++;
                        if (btns[i + 1, j - 1].GetMine())
                            count++;
                        btns[i, j].SetNum(count);
                    }
                    else if (i == r - 1 && j == c - 1)  //맨 오른쪽 아래 버튼
                    {
                        if (btns[i - 1, j].GetMine())
                            count++;
                        if (btns[i, j - 1].GetMine())
                            count++;
                        if (btns[i - 1, j - 1].GetMine())
                            count++;
                        btns[i, j].SetNum(count);
                    }
                    else if (i==0 && j!= 0)             //맨 왼줄
                    {
                        if (btns[i, j - 1].GetMine())
                            count++;
                        if (btns[i + 1, j - 1].GetMine())
                            count++;
                        if (btns[i + 1, j].GetMine())
                            count++;
                        if (btns[i + 1, j + 1].GetMine())
                            count++;
                        if (btns[i, j + 1].GetMine())
                            count++;
                        btns[i, j].SetNum(count);
                    }
                    else if (i == r - 1 && j != 0)      //맨 오른줄
                    {
                        if (btns[i, j - 1].GetMine())
                            count++;
                        if (btns[i - 1, j - 1].GetMine())
                            count++;
                        if (btns[i - 1, j].GetMine())
                            count++;
                        if (btns[i - 1, j + 1].GetMine())
                            count++;
                        if (btns[i, j + 1].GetMine())
                            count++;
                        btns[i, j].SetNum(count);
                    }
                    else if (i != 0 && j == 0)          //맨 윗줄
                    {
                        if (btns[i - 1, j].GetMine())
                            count++;
                        if (btns[i - 1, j + 1].GetMine())
                            count++;
                        if (btns[i, j + 1].GetMine())
                            count++;
                        if (btns[i + 1, j + 1].GetMine())
                            count++;
                        if (btns[i + 1, j].GetMine())
                            count++;
                        btns[i, j].SetNum(count);
                    }
                    else if (i != 0 && j == c - 1)      //맨 아랫줄
                    {
                        if (btns[i - 1, j].GetMine())
                            count++;
                        if (btns[i - 1, j - 1].GetMine())
                            count++;
                        if (btns[i, j - 1].GetMine())
                            count++;
                        if (btns[i + 1, j - 1].GetMine())
                            count++;
                        if (btns[i + 1, j].GetMine())
                            count++;
                        btns[i, j].SetNum(count);
                    }
                    else                                //나머지
                    {
                        if (btns[i + 1, j - 1].GetMine())
                            count++;
                        if (btns[i + 1, j].GetMine())
                            count++;
                        if (btns[i + 1, j + 1].GetMine())
                            count++;
                        if (btns[i - 1, j - 1].GetMine())
                            count++;
                        if (btns[i - 1, j].GetMine())
                            count++;
                        if (btns[i - 1, j + 1].GetMine())
                            count++;
                        if (btns[i, j - 1].GetMine())
                            count++;
                        if (btns[i, j + 1].GetMine())
                            count++;
                        btns[i, j].SetNum(count);
                    }
                }
            }
            return btns;
        }
        private void Clicked(object sender, MouseEventArgs e)
        {
            if(e.Button == MouseButtons.Left)
            {
                Left_Click((MyButton)sender);
            }
            else if(e.Button == MouseButtons.Right)
            {
                Right_Click((MyButton)sender);
            }
        }
        private void Left_Click(MyButton btn)
        {
            if (btn.Text != "▶")
            {
                if (btn.GetMine())
                {
                    this.Enabled = false;
                    Replay replay = new Replay(2);
                    replay.Owner = this;
                    replay.Show();
                }
                else
                {
                    if(btn.GetNum() == 0)
                    {
                        int x = btn.Location.X / 30;
                        int y = btn.Location.Y / 30;
                        btn.Enabled = false;
                        gameinfo.BlockClicked();
                        if (x - 1 > -1)
                        {
                            if (btns[x - 1, y].Enabled)
                                Left_Click(btns[x - 1, y]);
                            if (y - 1 > -1)
                            {
                                if (btns[x-1, y-1].Enabled)
                                    Left_Click(btns[x - 1, y - 1]);
                            }
                            if (y + 1 < gameinfo.GetCol())
                            {
                                if (btns[x-1, y+1].Enabled)
                                    Left_Click(btns[x - 1, y + 1]);
                            }
                        }
                        if (x+1<gameinfo.GetRow())
                        {
                            if (btns[x+1, y].Enabled)
                                Left_Click(btns[x + 1, y]);
                            if (y - 1 > -1)
                            {
                                if (btns[x+1, y-1].Enabled)
                                    Left_Click(btns[x + 1, y - 1]);
                            }
                            if (y + 1 < gameinfo.GetCol())
                            {
                                if (btns[x+1, y+1].Enabled)
                                    Left_Click(btns[x + 1, y + 1]);
                            }
                        }
                        if (y - 1 > -1)
                        {
                            if (btns[x, y-1].Enabled)
                                Left_Click(btns[x, y - 1]);
                        }
                        if(y+1 < gameinfo.GetCol())
                        {
                            if (btns[x, y+1].Enabled)
                                Left_Click(btns[x, y + 1]);
                        }
                    }
                    else
                    {
                        btn.Text += btn.GetNum();
                        btn.Enabled = false;
                        gameinfo.BlockClicked();
                    }
                }
            }
            else
            {
                return;
            }
            if(gameinfo.GetLeft() == gameinfo.GetMines())
            {
                this.Enabled = false;
                Replay replay = new Replay(1);
                replay.Owner = this;
                replay.Show();
            }
        }
        private void Right_Click(MyButton btn)
        {
            if(btn.Text != "▶")
            {
                if (gameinfo.GetFlags() > 0)
                {
                    btn.Text = "▶";
                    gameinfo.SetFlag(-1);
                    if (btn.GetMine())
                    {
                        gameinfo.SetFound(1);
                    }
                }
            }
            else
            {
                btn.Text = "";
                gameinfo.SetFlag(1);
                if (btn.GetMine())
                {
                    gameinfo.SetFound(-1);
                }
            }
            if(gameinfo.GetFound() == gameinfo.GetMines())
            {
                this.Enabled = false;
                Replay replay = new Replay(1);
                replay.Owner = this;
                replay.Show();
            }
        }

        private void PlayBoard_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Owner.Show();
        }
    }
    public class MyButton : Button
    {
        private int num = 1;
        private bool isMine = false;

        public int GetNum()
        {
            return this.num;
        }
        public void SetNum(int n) 
        {
            this.num = n;
        }
        public bool GetMine()
        {
            return this.isMine;
        }
        public void setMine(bool set)
        {
            this.isMine = set;
        }
    }
    public class GameInfo
    {
        private int difficult = 1;
        private int flags = 10;
        private int leftblocks = 81;
        private int mines = 10;
        private int found = 0;
        private int row = 0;
        private int col = 0;

        public void SetEasy()
        {
            this.difficult = 1;
            this.flags = 10;
            this.leftblocks = 81;
            this.mines = 10;
            this.row = 9;
            this.col = 9;
        }
        public void SetNormal()
        {
            this.difficult = 2;
            this.flags = 40;
            this.leftblocks = 256;
            this.mines = 40;
            this.row = 16;
            this.col = 16;
        }
        public void SetHard()
        {
            this.difficult = 3;
            this.flags = 99;
            this.leftblocks = 480;
            this.mines = 99;
            this.row = 30;
            this.col = 16;
        }
        public int GetDif()
        {
            return this.difficult;
        }
        public int GetFlags()
        {
            return this.flags;
        }
        public int GetLeft()
        {
            return this.leftblocks;
        }
        public void SetFound(int i)
        {
            this.found+=i;
        }
        public int GetFound()
        {
            return this.found;
        }
        public void BlockClicked()
        {
            this.leftblocks--;
        }
        public void SetFlag(int i)
        {
            this.flags += i;
        }
        public int GetMines()
        {
            return this.mines;
        }
        public int GetRow()
        {
            return this.row;
        }
        public int GetCol()
        {
            return this.col;
        }
    }
}
