﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 지뢰찾기
{
    public partial class Replay : Form
    {
        public Replay()
        {
            InitializeComponent();
        }
        public Replay(int i)
        {
            InitializeComponent();
            switch (i)
            {
                case 1:
                    lblVoD.Text = "You Win!";
                    break;
                case 2:
                    lblVoD.Text = "You Lose!";
                    break;
            }
        }

        private void btnYes_Click(object sender, EventArgs e)
        {
            this.Owner.Close();
            this.Close();
        }

        private void btnNo_Click(object sender, EventArgs e)
        {
            this.Owner.Owner.Close();
            this.Owner.Close();
            this.Close();
        }
    }
}
