﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 지뢰찾기
{
    public partial class SetDifficult : Form
    {
        private int difficulty = 1;          // 1 :초급  2 : 중급  3 : 고급

        public SetDifficult()
        {
            InitializeComponent();
        }

        private void rdobtnEasy_CheckedChanged(object sender, EventArgs e)
        {
            difficulty = 1;
        }
        private void rdobtnNormal_CheckedChanged(object sender, EventArgs e)
        {
            difficulty = 2;
        }

        private void rdobtnHard_CheckedChanged(object sender, EventArgs e)
        {
            difficulty = 3;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            switch (difficulty)
            {
                case 1:
                    StartEasy();
                    break;
                case 2:
                    StartNormal();
                    break;
                case 3:
                    StartHard();
                    break;
            }
        }
        private void StartEasy()
        {
            this.Visible = false;
            PlayBoard pb = new PlayBoard(1);
            pb.Owner = this;
            pb.Show();
        }
        private void StartNormal()
        {
            this.Visible = false;
            PlayBoard pb = new PlayBoard(2);
            pb.Owner = this;
            pb.ShowDialog();
        }
        private void StartHard()
        {
            this.Visible = false;
            PlayBoard pb = new PlayBoard(3);
            pb.Owner = this;
            pb.ShowDialog();
        }

    }
}
