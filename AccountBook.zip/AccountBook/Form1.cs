﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public enum ControlParseCase
        {
            None,
            Name,
            Money
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)     //Form load
        {
            lblTime.Text = DateTime.Now.ToString("yyyy.M.");
            lvwOutgo.View = View.Details;
            lvwOutgo.Columns.Add("Name", "Name");
            lvwOutgo.Columns.Add("Money", "Cost");
            lvwOutgo.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
            lvwOutgo.Columns["Money"].TextAlign = HorizontalAlignment.Center;
            lvwIncome.View = View.Details;
            lvwIncome.Columns.Add("Name", "Name");
            lvwIncome.Columns.Add("Money", "Income");
            lvwIncome.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
            lvwIncome.Columns["Money"].TextAlign = HorizontalAlignment.Center;
            lvwIncome.Items.Clear();
            lvwOutgo.Items.Clear();
            string directory_path = "Data";
            if (!Directory.Exists(directory_path))
            {
                Directory.CreateDirectory(directory_path);
            }

            if (File.Exists("Data\\" + lblTime.Text + "Income.txt") || File.Exists("Data\\" + lblTime.Text + "Cost.txt"))
            {   
                LoadData();
            }
        }

        private void btnPrev_Click(object sender, EventArgs e)      //click previous button
        {
            DateTime t = DateTime.Parse(lblTime.Text);
            t = t.AddMonths(-1);
            lblTime.Text = t.ToString("yyyy.M.");
            lvwIncome.Items.Clear();
            lvwOutgo.Items.Clear();
            if (File.Exists("Data\\" + lblTime.Text + "Income.txt") || File.Exists("Data\\" + lblTime.Text + "Cost.txt"))
            {
                LoadData();
            }
            clearControlsI();
            clearControlsO();
            EvalOutgo();
            EvalIncome();
            Total();
        }

        private void btnNext_Click(object sender, EventArgs e)          //When clicking next month
        {
            DateTime t = DateTime.Parse(lblTime.Text);
            t = t.AddMonths(1);
            lblTime.Text = t.ToString("yyyy.M.");
            lvwIncome.Items.Clear();
            lvwOutgo.Items.Clear();
            if (File.Exists("Data\\" + lblTime.Text + "Income.txt") || File.Exists("Data\\" + lblTime.Text + "Cost.txt"))
            {
                LoadData();
            }
            clearControlsO();
            clearControlsI();
            EvalOutgo();
            EvalIncome();
            Total();
        }

        private void clearControlsO()           //clear the income and cost box
        {

            tbOutMoney.Clear();
            tbOutName.Clear();
        }
        private ControlParseCase GetControlParseCaseO()
        {
            if (string.Equals(tbOutMoney.Text, String.Empty)) return ControlParseCase.Money;
            else if (string.Equals(tbOutName.Text, String.Empty)) return ControlParseCase.Name;
            return ControlParseCase.None;
        }
        private Dictionary<string,string> GetControlParseDictO()
        {
            return new Dictionary<string, string>()
            {
                { "Name", tbOutName.Text },
                {"Money", tbOutMoney.Text }
            };

        }
        private void btnAddO_Click(object sender, EventArgs e)      //adding cost
        {
            if (GetControlParseCaseO() != ControlParseCase.None) return;
            for(int i = 0; i < tbOutMoney.TextLength; i++)
            {
                if (!Char.IsDigit(tbOutMoney.Text[i]))
                {
                    MessageBox.Show("Please use the digits only!");
                    tbOutMoney.Clear();
                    return;
                }
            }
            var lvwItem = new ListViewItem(new string[lvwOutgo.Columns.Count]);

            for (int i = 0; i < lvwOutgo.Columns.Count; i++)
                lvwItem.SubItems[i].Name = lvwOutgo.Columns[i].Name;

            var controlParseDict = GetControlParseDictO();
            foreach (string item in controlParseDict.Keys)
                lvwItem.SubItems[item].Text = controlParseDict[item];

            lvwOutgo.Items.Add(lvwItem);

            clearControlsO();

            EvalOutgo();

            Total();
        }

        private void btnDelO_Click(object sender, EventArgs e)      //del cost
        {
            if (lvwOutgo.FocusedItem == null) return;
            lvwOutgo.FocusedItem.Remove();
            EvalOutgo();
            Total();
        }
        private void EvalOutgo()                               //calculate all cost
        {
            int sum = 0;
            for (int i = 0; i < lvwOutgo.Items.Count; i++)
            {
                var lvwitems = new ListViewItem(new string[lvwOutgo.Columns.Count]);
                lvwitems = lvwOutgo.Items[i];
                sum += Int32.Parse(lvwitems.SubItems["money"].Text);
            }
            lblOutgo.Text = "All cost : " + sum + "$";
        }
        private void clearControlsI()               //income box clear
        {
            tbInMoney.Clear();
            tbInName.Clear();
        }                       
        private ControlParseCase GetControlParseCaseI()
        {
            if (string.Equals(tbInMoney.Text, String.Empty)) return ControlParseCase.Money;
            else if (string.Equals(tbInName.Text, String.Empty)) return ControlParseCase.Name;
            return ControlParseCase.None;
        }
        private Dictionary<string, string> GetControlParseDictI()
        {
            return new Dictionary<string, string>()
            {
                { "Name", tbInName.Text },
                {"Money", tbInMoney.Text }
            };

        }
        private void btnAddI_Click(object sender, EventArgs e)      //adding income
        {
            if (GetControlParseCaseI() != ControlParseCase.None) return;

            for (int i = 0; i < tbInMoney.TextLength; i++)
            {
                if (!Char.IsDigit(tbInMoney.Text[i]))
                {
                    MessageBox.Show("Please use the digits only!");
                    tbInMoney.Clear();
                    return;
                }
            }

            var lvwItem = new ListViewItem(new string[lvwIncome.Columns.Count]);

            for (int i = 0; i < lvwIncome.Columns.Count; i++)
                lvwItem.SubItems[i].Name = lvwIncome.Columns[i].Name;

            var controlParseDict = GetControlParseDictI();
            foreach (string item in controlParseDict.Keys)
                lvwItem.SubItems[item].Text = controlParseDict[item];

            lvwIncome.Items.Add(lvwItem);
            clearControlsI();
            EvalIncome();
            Total();
        }

        private void btnDelI_Click(object sender, EventArgs e)      //delete income
        {
            if (lvwIncome.FocusedItem == null) return;
            lvwIncome.FocusedItem.Remove();
            EvalIncome();
            Total();
        }
        private void EvalIncome()               //calculate all income
        {
            int sum = 0;
            for (int i = 0; i < lvwIncome.Items.Count; i++)
            {
                var lvwitems = new ListViewItem(new string[lvwIncome.Columns.Count]);
                lvwitems = lvwIncome.Items[i];
                sum += Int32.Parse(lvwitems.SubItems["Money"].Text);
            }

            lblIncome.Text = "총 수입 : " + sum + "원";
        }
        private void Total()                    //calculate all of the money
        {
            int total = 0;
 
            for (int i = 0; i < lvwIncome.Items.Count; i++)
            {
                var lvwitems = new ListViewItem(new string[lvwIncome.Columns.Count]);
                lvwitems = lvwIncome.Items[i];
                total += Int32.Parse(lvwitems.SubItems["money"].Text);
            }
            for (int i = 0; i < lvwOutgo.Items.Count; i++)
            {
                var lvwitems = new ListViewItem(new string[lvwOutgo.Columns.Count]);
                lvwitems = lvwOutgo.Items[i];
                total -= Int32.Parse(lvwitems.SubItems["money"].Text);
            }
            lblSum.Text = ("All of the money : "+total+"$");
        }
        
        private void LoadData()                 //Read file
        {
            LoadOutgo();
            LoadIncome();
        }
        public void LoadOutgo()                 //read Cost file
        {
            string FileName = "Data\\" + lblTime.Text + "Cost.txt";
            if (!File.Exists(FileName))
            {
                return;
            }
            else
            {
                StreamReader sr = new StreamReader(FileName);
                while (true)
                {
                    string read = sr.ReadLine();
                    if (read == null)
                        break;

                    string name = null;
                    string money = null;
                    string[] list = read.Split(':');
                    string[] list2 = list[1].Split(' ');

                    name = list2[1];
                    money = list[2].Trim();

                    var lvwItem = new ListViewItem(new string[lvwOutgo.Columns.Count]);

                    for (int i = 0; i < lvwOutgo.Columns.Count; i++)
                        lvwItem.SubItems[i].Name = lvwOutgo.Columns[i].Name;

                    lvwItem.SubItems["Name"].Text = name;
                    lvwItem.SubItems["Money"].Text = money;

                    lvwOutgo.Items.Add(lvwItem);
                }
                sr.Close();
                EvalIncome();
                EvalOutgo();
                Total();
            }
        }
        public void LoadIncome()                //read income file
        {
            string FileName = "Data\\" + lblTime.Text + "Income.txt";
            if (!File.Exists(FileName))
            {
                return;
            }
            else
            {
                StreamReader sr = new StreamReader(FileName);
                while (true)
                {
                    string read = sr.ReadLine();
                    if (read == null)
                        break;

                    string name = null;
                    string money = null;
                    string[] list = read.Split(':');
                    string[] list2 = list[1].Split(' ');

                    name = list2[1];
                    money = list[2].Trim();

                    var lvwItem = new ListViewItem(new string[lvwIncome.Columns.Count]);

                    for (int i = 0; i < lvwIncome.Columns.Count; i++)
                        lvwItem.SubItems[i].Name = lvwIncome.Columns[i].Name;

                    lvwItem.SubItems["Name"].Text = name;
                    lvwItem.SubItems["Money"].Text = money;

                    lvwIncome.Items.Add(lvwItem);
                }
                sr.Close();
                EvalIncome();
                EvalOutgo();
                Total();
            }
        }
        private void btnSave_Click(object sender, EventArgs e)      //click save account book
        {
            SaveData();
        }
        private void SaveData()                 //save account book
        {
            try
            {
                string FileName = "Data\\" + lblTime.Text + "Cost.txt";
                StreamWriter sw = new StreamWriter(FileName);
                for (int i = 0; i < lvwOutgo.Items.Count; i++)
                {
                    var lvwitems = new ListViewItem(new string[lvwOutgo.Columns.Count]);
                    lvwitems = lvwOutgo.Items[i];

                    sw.WriteLine("Name : " + lvwitems.SubItems["Name"].Text + " Money : " + lvwitems.SubItems["Money"].Text);
                }
                sw.Close();
            }
            catch
            {
                MessageBox.Show("Fail.");
            }
            try
            {
                string FileName = "Data\\" + lblTime.Text + "Income.txt";
                StreamWriter sw = new StreamWriter(FileName);
                for (int i = 0; i < lvwIncome.Items.Count; i++)
                {
                    var lvwitems = new ListViewItem(new string[lvwIncome.Columns.Count]);
                    lvwitems = lvwIncome.Items[i];

                    sw.WriteLine("Name : " + lvwitems.SubItems["Name"].Text + " Money : " + lvwitems.SubItems["Money"].Text);
                }
                sw.Close();
            }
            catch
            {
                MessageBox.Show("Fail.");
            }
            MessageBox.Show("Save complete.");
        }


    }
}
